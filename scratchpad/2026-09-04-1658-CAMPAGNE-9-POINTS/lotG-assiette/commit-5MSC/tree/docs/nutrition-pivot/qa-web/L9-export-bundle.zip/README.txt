EXPORT DE TES DONNÉES SOPHIA
============================

Export généré le : 5 août 2026

Contenu de l'archive :
  - profil.json          : tes informations de compte (nom, email, téléphone…).
  - transformations.json : tes cycles et transformations tels que visibles dans l'app.
  - plans.json           : tes plans et les actions qui les composent.
  - suivi.json           : tes entrées de suivi (check-ins, progrès, blocages).
  - souvenirs.json       : les souvenirs que Sophia a retenus de vos échanges.
  - conversations.json   : l'historique de tes conversations avec Sophia.
  - protocole.json       : le protocole écrit par ton coach (versions, engagements,
                           relations entre engagements) et, si tu es coach, tes
                           modèles, documents importés, doctrine, cohortes et
                           l'agrégat de tes synthèses hebdomadaires.
  - mon_plan.json        : ton objectif, les semaines que tu t'es fixées et tes
                           points du soir.
  - ma_memoire_alimentaire.json : tes repas récurrents, tes préférences et ton
                           contexte, et les idées de repas reçues.
  - mes_cartes.json      : tes cartes, quand elles ont été armées et ce que tu en
                           as fait.
  - protocole_suivi.json : ce que tu as déclaré (repas, prises, photos) et les
                           évaluations qui en découlent, jour par jour.
  - protocole_bilans.json: tes bilans hebdomadaires et tes demandes d'ajustement.
  - securite.json        : tes contraintes de sécurité (allergies, intolérances,
                           traitements) telles que déclarées.
  - coaching.json        : tes liens avec un coach, les invitations reçues ou
                           envoyées, et les accès à ton dossier.
  - fichiers.json        : la liste de tes fichiers, avec pour chacun s'il est
                           inclus dans l'archive et, sinon, pourquoi. Si son
                           champ « tables_indisponibles » n'est pas vide, une
                           partie des données ci-dessus manque : écris-nous.
  - fichiers/            : tes documents de plan et tes photos de repas.

⚠ AVERTISSEMENT
Ce fichier contient des données personnelles sensibles (dont l'historique de
tes conversations). Conserve-le en lieu sûr, ne le partage pas et supprime-le
des espaces partagés ou synchronisés si tu n'en as plus besoin.

Format : JSON (UTF-8), lisible avec n'importe quel éditeur de texte.
Pour toute question : sophia@sophia-coach.ai
